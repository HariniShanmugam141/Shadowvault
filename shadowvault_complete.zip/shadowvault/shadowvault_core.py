"""
ShadowVault Core Engine
- PII Detection (Regex + spaCy + Ollama LLM)
- Reversible Anonymization (AES-256 Token Vault)
- Cross-Document Entity Linking
- Compliance Profiles
- Privacy Risk Score
"""

import os
import re
import json
import uuid
import hashlib
import sqlite3
import requests
from datetime import datetime
from pathlib import Path
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
import base64
import spacy
import fitz  # PyMuPDF
import pytesseract
import cv2
import io
from PIL import Image

# ──────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────

VAULT_DIR = Path("vault")
VAULT_DIR.mkdir(exist_ok=True)
VAULT_DB = VAULT_DIR / "shadowvault.db"
KEY_FILE = VAULT_DIR / "master.key"

TESSERACT_CONFIG = r"--oem 3 --psm 6"
OLLAMA_URL = "http://localhost:11434/api/generate"
OLLAMA_MODEL = "mistral"

# ──────────────────────────────────────────────
# COMPLIANCE PROFILES
# ──────────────────────────────────────────────

COMPLIANCE_PROFILES = {
    "GDPR": {
        "name": "GDPR (Europe)",
        "categories": ["NAME", "EMAIL", "PHONE", "ADDRESS", "DOB", "NATIONAL_ID",
                       "IP_ADDRESS", "COOKIE_ID", "LOCATION", "BIOMETRIC"],
        "description": "EU General Data Protection Regulation — protects all EU citizen personal data",
        "color": "#3B82F6"
    },
    "HIPAA": {
        "name": "HIPAA (Healthcare)",
        "categories": ["NAME", "DOB", "PHONE", "EMAIL", "ADDRESS", "SSN",
                       "MRN", "INSURANCE_ID", "MEMBER_ID", "DATES", "BIOMETRIC", "PHOTO"],
        "description": "US Health Insurance Portability and Accountability Act — protects patient health information",
        "color": "#10B981"
    },
    "DPDP": {
        "name": "DPDP Act 2023 (India)",
        "categories": ["NAME", "AADHAAR", "PAN", "PHONE", "EMAIL", "ADDRESS",
                       "DOB", "PASSPORT", "VOTER_ID", "BANK_ACCOUNT", "BIOMETRIC"],
        "description": "India's Digital Personal Data Protection Act 2023",
        "color": "#F59E0B"
    },
    "PCI_DSS": {
        "name": "PCI-DSS (Financial)",
        "categories": ["CARD_NUMBER", "CVV", "EXPIRY", "BANK_ACCOUNT",
                       "ROUTING_NUMBER", "NAME", "SSN", "PHONE", "EMAIL"],
        "description": "Payment Card Industry Data Security Standard",
        "color": "#EF4444"
    },
    "CUSTOM": {
        "name": "Custom Profile",
        "categories": ["NAME", "EMAIL", "PHONE", "SSN", "DOB", "ADDRESS"],
        "description": "User-defined detection categories",
        "color": "#8B5CF6"
    }
}

# ──────────────────────────────────────────────
# REGEX PATTERNS (ALL PII TYPES)
# ──────────────────────────────────────────────

ALL_REGEX_PATTERNS = {
    "NAME":         r"(?:Name[:\s]+)([A-Z][a-z]+(?:\s[A-Z]\.?)?\s[A-Z][a-z]+)",
    "DOB":          r"(?:DOB|Date\s*of\s*Birth)[:\s]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
    "EMAIL":        r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
    "PHONE":        r"(?:\+91[\s-]?)?[6-9]\d{9}|(?:\+\d{1,2}[\s-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}",
    "SSN":          r"\b\d{3}-\d{2}-\d{4}\b",
    "AADHAAR":      r"\b\d{4}\s?\d{4}\s?\d{4}\b",
    "PAN":          r"\b[A-Z]{5}[0-9]{4}[A-Z]\b",
    "PASSPORT":     r"(?:Passport[:\s]+)([A-Z][0-9]{7}|[A-Z]{2}[0-9]{7})",
    "VOTER_ID":     r"\b[A-Z]{3}[0-9]{7}\b",
    "BANK_ACCOUNT": r"\b\d{9,18}\b",
    "CARD_NUMBER":  r"\b(?:\d{4}[\s-]?){4}\b",
    "CVV":          r"(?:CVV|CVC)[:\s]*(\d{3,4})",
    "EXPIRY":       r"\b(0[1-9]|1[0-2])[/\-]\d{2,4}\b",
    "MRN":          r"(?:MRN|Medical\s*Record)[:\s]*([A-Z0-9-]{6,15})",
    "INSURANCE_ID": r"(?:Insurance\s*ID|Policy\s*No)[:\s]*([A-Z0-9-]{6,15})",
    "MEMBER_ID":    r"(?:Member\s*ID)[:\s]*([A-Z0-9-]{6,15})",
    "NPI_ID":       r"(?:NPI)[:\s]*(\d{8,10})",
    "ADDRESS":      r"\d{1,5}\s+[A-Za-z0-9\s]+(Street|St|Road|Rd|Avenue|Ave|Drive|Dr|Lane|Ln|Nagar|Colony|Sector)\b[^\n]*",
    "CITY_STATE":   r"[A-Z][a-z]+,\s?[A-Z]{2}\s?\d{5}(?:-\d{4})?",
    "IP_ADDRESS":   r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "DATE_NUMERIC": r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b",
    "ZIP":          r"\b\d{6}\b|\b\d{5}(?:-\d{4})?\b",
}

# ──────────────────────────────────────────────
# ENCRYPTION / KEY VAULT
# ──────────────────────────────────────────────

def generate_or_load_master_key():
    """Generate or load AES-256 master encryption key."""
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    return key

MASTER_KEY = generate_or_load_master_key()
CIPHER = Fernet(MASTER_KEY)

def encrypt_value(plaintext: str) -> str:
    return CIPHER.encrypt(plaintext.encode()).decode()

def decrypt_value(ciphertext: str) -> str:
    return CIPHER.decrypt(ciphertext.encode()).decode()

# ──────────────────────────────────────────────
# VAULT DATABASE
# ──────────────────────────────────────────────

def init_db():
    """Initialize SQLite vault database."""
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS tokens (
            token_id TEXT PRIMARY KEY,
            encrypted_value TEXT NOT NULL,
            pii_label TEXT NOT NULL,
            allowed_roles TEXT NOT NULL,
            document_id TEXT,
            entity_id TEXT,
            created_at TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS entities (
            entity_id TEXT PRIMARY KEY,
            canonical_name TEXT NOT NULL,
            pseudonym TEXT NOT NULL,
            document_ids TEXT NOT NULL,
            pii_label TEXT,
            created_at TEXT
        )
    """)
    c.execute("""
        CREATE TABLE IF NOT EXISTS documents (
            doc_id TEXT PRIMARY KEY,
            filename TEXT,
            compliance_profile TEXT,
            risk_score REAL,
            processed_at TEXT,
            token_count INTEGER
        )
    """)
    conn.commit()
    conn.close()

init_db()

def store_token(real_value: str, pii_label: str, allowed_roles: list,
                document_id: str = None, entity_id: str = None) -> str:
    """Encrypt real value, store in vault, return token ID."""
    token_id = f"SV-TOKEN-{uuid.uuid4().hex[:8].upper()}"
    encrypted = encrypt_value(real_value)
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("""
        INSERT INTO tokens (token_id, encrypted_value, pii_label, allowed_roles,
                            document_id, entity_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (token_id, encrypted, pii_label, json.dumps(allowed_roles),
          document_id, entity_id, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return token_id

def retrieve_token(token_id: str, role: str) -> dict:
    """Retrieve and decrypt token if role is authorized."""
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT * FROM tokens WHERE token_id = ?", (token_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return {"success": False, "error": "Token not found"}
    allowed_roles = json.loads(row[3])
    if role not in allowed_roles and role != "admin":
        return {"success": False, "error": f"Role '{role}' not authorized for this field"}
    real_value = decrypt_value(row[1])
    return {"success": True, "value": real_value, "label": row[2], "token_id": token_id}

def get_all_tokens_for_document(doc_id: str) -> list:
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT token_id, pii_label, allowed_roles FROM tokens WHERE document_id = ?", (doc_id,))
    rows = c.fetchall()
    conn.close()
    return [{"token_id": r[0], "label": r[1], "roles": json.loads(r[2])} for r in rows]

# ──────────────────────────────────────────────
# ROLE-BASED ACCESS CONFIG
# ──────────────────────────────────────────────

ROLE_PERMISSIONS = {
    "admin":    ["NAME", "DOB", "SSN", "AADHAAR", "PAN", "EMAIL", "PHONE",
                 "ADDRESS", "MRN", "INSURANCE_ID", "CARD_NUMBER", "BANK_ACCOUNT",
                 "PASSPORT", "VOTER_ID", "MEMBER_ID"],
    "doctor":   ["NAME", "DOB", "MRN", "PHONE", "EMAIL", "ADDRESS", "INSURANCE_ID", "MEMBER_ID"],
    "auditor":  ["AADHAAR", "PAN", "SSN", "BANK_ACCOUNT", "INSURANCE_ID", "CARD_NUMBER"],
    "legal":    ["NAME", "DOB", "ADDRESS", "PASSPORT", "VOTER_ID", "SSN"],
    "analyst":  ["ZIP", "DATE_NUMERIC", "INSURANCE_ID"],
    "viewer":   []
}

def get_roles_for_label(label: str) -> list:
    """Get which roles can decrypt a given PII label."""
    return [role for role, labels in ROLE_PERMISSIONS.items() if label in labels]

# ──────────────────────────────────────────────
# SPACY NLP
# ──────────────────────────────────────────────

try:
    nlp = spacy.load("en_core_web_sm")
except Exception:
    print("[!] spaCy model not found. Run: python -m spacy download en_core_web_sm")
    nlp = None

# ──────────────────────────────────────────────
# OLLAMA LLM CONTEXTUAL DETECTION
# ──────────────────────────────────────────────

def detect_contextual_pii_ollama(text: str) -> list:
    """Use Ollama/Mistral to detect implied/contextual PII."""
    if not text or len(text.strip()) < 20:
        return []
    prompt = f"""You are a privacy expert. Analyze the following text and identify ALL personally identifiable information (PII), including:
- Direct PII: names, phone numbers, emails, IDs
- Indirect/contextual PII: phrases that could identify someone (e.g. "the CEO's wife", "patient in Ward 3B")
- Quasi-identifiers: combinations that together identify someone (age + ZIP + gender)

Text: {text[:2000]}

Respond ONLY with a JSON array. Each item: {{"text": "the PII phrase", "label": "PII_TYPE", "reason": "why it's PII"}}
If no PII found, return [].
JSON array only, no other text."""

    try:
        resp = requests.post(OLLAMA_URL, json={
            "model": OLLAMA_MODEL,
            "prompt": prompt,
            "stream": False
        }, timeout=30)
        if resp.status_code == 200:
            raw = resp.json().get("response", "")
            # Extract JSON array from response
            match = re.search(r'\[.*\]', raw, re.DOTALL)
            if match:
                return json.loads(match.group())
    except Exception as e:
        print(f"[!] Ollama error: {e}")
    return []

def is_ollama_running() -> bool:
    try:
        r = requests.get("http://localhost:11434/api/tags", timeout=3)
        return r.status_code == 200
    except Exception:
        return False

# ──────────────────────────────────────────────
# PII DETECTION ENGINE
# ──────────────────────────────────────────────

def detect_pii(text: str, profile: str = "GDPR", use_llm: bool = True) -> list:
    """
    Full PII detection pipeline:
    1. Regex patterns
    2. spaCy NER
    3. Ollama LLM (contextual)
    Returns list of (text, label) tuples
    """
    if not text:
        return []

    profile_categories = COMPLIANCE_PROFILES.get(profile, COMPLIANCE_PROFILES["GDPR"])["categories"]
    entities = []

    # Layer 1: Regex
    for label, pattern in ALL_REGEX_PATTERNS.items():
        if label not in profile_categories:
            continue
        try:
            for match in re.finditer(pattern, text, re.IGNORECASE):
                val = match.group(1) if match.lastindex else match.group(0)
                val = val.strip()
                if val and len(val) > 2:
                    entities.append((val, label, "regex"))
        except re.error:
            pass

    # Layer 2: spaCy NER
    if nlp:
        doc = nlp(text[:100000])
        label_map = {"PERSON": "NAME", "GPE": "LOCATION", "LOC": "LOCATION",
                     "ORG": "ORGANIZATION", "DATE": "DATE", "CARDINAL": "ID"}
        for ent in doc.ents:
            mapped = label_map.get(ent.label_)
            if mapped and mapped in profile_categories:
                val = ent.text.strip()
                if val and len(val.replace(" ", "")) > 2:
                    entities.append((val, mapped, "spacy"))

    # Layer 3: Ollama LLM contextual
    if use_llm and is_ollama_running():
        llm_results = detect_contextual_pii_ollama(text)
        for item in llm_results:
            val = item.get("text", "").strip()
            label = item.get("label", "CONTEXTUAL_PII").upper()
            if val:
                entities.append((val, label, "llm"))

    # Deduplicate
    seen = set()
    unique = []
    for val, label, source in entities:
        key = val.strip().lower()
        if key not in seen and len(key) > 1:
            seen.add(key)
            unique.append((val.strip(), label, source))

    return unique

# ──────────────────────────────────────────────
# CROSS-DOCUMENT ENTITY LINKING
# ──────────────────────────────────────────────

def normalize_name(name: str) -> str:
    """Normalize name for fuzzy matching."""
    return re.sub(r'\s+', ' ', name.strip().lower())

def names_match(n1: str, n2: str) -> bool:
    """Check if two name strings refer to the same person."""
    n1, n2 = normalize_name(n1), normalize_name(n2)
    if n1 == n2:
        return True
    # Check if one is abbreviation of other (e.g. "H. Shankar" vs "Harini Shankar")
    parts1, parts2 = n1.split(), n2.split()
    if len(parts1) >= 2 and len(parts2) >= 2:
        # Last names match
        if parts1[-1] == parts2[-1]:
            # First initial match
            if parts1[0][0] == parts2[0][0]:
                return True
    return False

def get_or_create_entity(canonical_name: str, pii_label: str, doc_id: str) -> str:
    """Find existing entity or create new pseudonym."""
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT entity_id, canonical_name, pseudonym, document_ids FROM entities WHERE pii_label = ?",
              (pii_label,))
    rows = c.fetchall()

    for row in rows:
        eid, cname, pseudo, doc_ids_str = row
        if names_match(canonical_name, cname):
            # Update document list
            doc_ids = json.loads(doc_ids_str)
            if doc_id not in doc_ids:
                doc_ids.append(doc_id)
                c.execute("UPDATE entities SET document_ids = ? WHERE entity_id = ?",
                          (json.dumps(doc_ids), eid))
                conn.commit()
            conn.close()
            return eid, pseudo

    # Create new entity
    entity_id = str(uuid.uuid4())
    count = len(rows) + 1
    pseudonym = f"PERSON-{count:04d}" if pii_label == "NAME" else f"ENTITY-{count:04d}"
    c.execute("""
        INSERT INTO entities (entity_id, canonical_name, pseudonym, document_ids, pii_label, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (entity_id, canonical_name, pseudonym, json.dumps([doc_id]),
          pii_label, datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return entity_id, pseudonym

def get_all_entities() -> list:
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT * FROM entities ORDER BY created_at DESC")
    rows = c.fetchall()
    conn.close()
    return [{"entity_id": r[0], "canonical_name": r[1], "pseudonym": r[2],
             "document_ids": json.loads(r[3]), "label": r[4]} for r in rows]

# ──────────────────────────────────────────────
# PRIVACY RISK SCORE
# ──────────────────────────────────────────────

PII_RISK_WEIGHTS = {
    "SSN": 10, "AADHAAR": 10, "PAN": 9, "CARD_NUMBER": 10,
    "BANK_ACCOUNT": 9, "PASSPORT": 9, "VOTER_ID": 8,
    "NAME": 7, "DOB": 7, "MRN": 8, "BIOMETRIC": 10,
    "EMAIL": 5, "PHONE": 6, "ADDRESS": 6, "IP_ADDRESS": 4,
    "DATE_NUMERIC": 2, "ZIP": 2, "LOCATION": 3,
    "CONTEXTUAL_PII": 8, "INSURANCE_ID": 6, "MEMBER_ID": 5,
}

def calculate_privacy_risk_score(entities: list, total_words: int = 100) -> dict:
    """
    Calculate Privacy Risk Score using weighted PII density.
    Returns score 0-100 and breakdown.
    """
    if not entities:
        return {"score": 0, "level": "Low", "color": "#10B981", "breakdown": {}}

    label_counts = {}
    for _, label, *_ in entities:
        label_counts[label] = label_counts.get(label, 0) + 1

    raw_score = 0
    breakdown = {}
    for label, count in label_counts.items():
        weight = PII_RISK_WEIGHTS.get(label, 3)
        contribution = weight * count
        raw_score += contribution
        breakdown[label] = {"count": count, "weight": weight, "contribution": contribution}

    # Normalize to 0-100
    max_possible = 200
    score = min(100, (raw_score / max_possible) * 100)

    # K-anonymity approximation
    unique_combos = len(set([(v, l) for v, l, *_ in entities]))
    k_anon_risk = max(0, 10 - unique_combos) * 2
    score = min(100, score + k_anon_risk)

    score = round(score, 1)

    if score >= 70:
        level, color = "Critical", "#EF4444"
    elif score >= 40:
        level, color = "High", "#F59E0B"
    elif score >= 20:
        level, color = "Medium", "#3B82F6"
    else:
        level, color = "Low", "#10B981"

    return {"score": score, "level": level, "color": color,
            "breakdown": breakdown, "entity_count": len(entities)}

# ──────────────────────────────────────────────
# TEXT EXTRACTION
# ──────────────────────────────────────────────

def extract_text_from_pdf(pdf_path: str) -> str:
    text_parts = []
    try:
        doc = fitz.open(pdf_path)
        for i, page in enumerate(doc):
            try:
                pt = page.get_text("text").strip()
            except Exception:
                pt = ""
            if pt:
                text_parts.append(pt)
            else:
                try:
                    pix = page.get_pixmap(dpi=300)
                    img = Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")
                    pt = pytesseract.image_to_string(img, config=TESSERACT_CONFIG)
                    text_parts.append(pt)
                except Exception as e:
                    print(f"[!] OCR error page {i}: {e}")
        doc.close()
    except Exception as e:
        print(f"[!] PDF error: {e}")
    return "\n\n".join(text_parts)

def extract_text_from_image(image_path: str) -> tuple:
    """Returns (text, ocr_data) for image."""
    img = cv2.imread(image_path)
    if img is None:
        return "", None
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    ocr_data = pytesseract.image_to_data(thresh, output_type=pytesseract.Output.DICT,
                                          config=TESSERACT_CONFIG)
    words = [w for w in ocr_data.get("text", []) if w and w.strip()]
    return " ".join(words), ocr_data

# ──────────────────────────────────────────────
# DOCUMENT PROCESSING ENGINE
# ──────────────────────────────────────────────

def process_document(file_path: str, profile: str = "GDPR",
                     use_llm: bool = True, reversible: bool = True) -> dict:
    """
    Main processing pipeline for a single document.
    Returns complete result dict.
    """
    doc_id = str(uuid.uuid4())
    filename = os.path.basename(file_path)
    ext = os.path.splitext(filename)[1].lower()
    output_dir = Path("outputs")
    output_dir.mkdir(exist_ok=True)
    output_path = str(output_dir / f"redacted_{doc_id[:8]}_{filename}")
    result = {
        "doc_id": doc_id,
        "filename": filename,
        "profile": profile,
        "entities": [],
        "token_map": {},
        "output_path": output_path,
        "risk_score": {},
        "face_count": 0,
        "error": None
    }

    try:
        if ext == ".pdf":
            text = extract_text_from_pdf(file_path)
            entities = detect_pii(text, profile, use_llm)
            result["entities"] = entities

            # Build token map for reversible anonymization
            token_map = {}
            if reversible:
                for val, label, source in entities:
                    if val not in token_map:
                        allowed_roles = get_roles_for_label(label)
                        # Cross-document entity linking for names
                        entity_id = None
                        if label == "NAME":
                            entity_id, pseudo = get_or_create_entity(val, label, doc_id)
                        tid = store_token(val, label, allowed_roles, doc_id, entity_id)
                        token_map[val] = {"token_id": tid, "label": label}

            result["token_map"] = token_map
            _redact_pdf(file_path, output_path, entities, token_map, reversible)

        elif ext in [".jpg", ".jpeg", ".png", ".tiff"]:
            text, ocr_data = extract_text_from_image(file_path)
            entities = detect_pii(text, profile, use_llm)
            result["entities"] = entities

            token_map = {}
            if reversible:
                for val, label, source in entities:
                    if val not in token_map:
                        allowed_roles = get_roles_for_label(label)
                        entity_id = None
                        if label == "NAME":
                            entity_id, pseudo = get_or_create_entity(val, label, doc_id)
                        tid = store_token(val, label, allowed_roles, doc_id, entity_id)
                        token_map[val] = {"token_id": tid, "label": label}

            result["token_map"] = token_map
            face_count = _redact_image(file_path, output_path, entities, ocr_data)
            result["face_count"] = face_count

        # Risk score
        risk = calculate_privacy_risk_score(entities, len(text.split()))
        result["risk_score"] = risk

        # Store document record
        conn = sqlite3.connect(VAULT_DB)
        c = conn.cursor()
        c.execute("""
            INSERT INTO documents (doc_id, filename, compliance_profile, risk_score, processed_at, token_count)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (doc_id, filename, profile, risk["score"],
              datetime.now().isoformat(), len(token_map)))
        conn.commit()
        conn.close()

    except Exception as e:
        result["error"] = str(e)
        import traceback
        traceback.print_exc()

    return result

def _redact_pdf(input_path, output_path, entities, token_map, reversible):
    doc = fitz.open(input_path)
    try:
        doc.set_metadata({})
    except Exception:
        pass
    for page in doc:
        for val, label, *_ in entities:
            val = val.strip()
            if not val or len(val) < 2:
                continue
            try:
                rects = page.search_for(val)
            except Exception:
                rects = []
            for r in rects:
                if reversible and val in token_map:
                    tid = token_map[val]["token_id"]
                    page.add_redact_annot(r, text=f"[{tid}]",
                                          fill=(0.1, 0.1, 0.3),
                                          text_color=(1, 1, 0))
                else:
                    page.add_redact_annot(r, fill=(0, 0, 0))
        page.apply_redactions()
    doc.save(output_path)
    doc.close()

def _redact_image(input_path, output_path, entities, ocr_data):
    img = cv2.imread(input_path)
    if img is None:
        return 0

    if ocr_data:
        for i, word in enumerate(ocr_data.get("text", [])):
            if not word or not word.strip():
                continue
            for val, label, *_ in entities:
                if word.strip().lower() in val.lower() or val.lower() in word.strip().lower():
                    x = ocr_data["left"][i]
                    y = ocr_data["top"][i]
                    w = ocr_data["width"][i]
                    h = ocr_data["height"][i]
                    cv2.rectangle(img, (x, y), (x + w, y + h), (0, 0, 0), -1)
                    break

    # Face detection
    face_cascade = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        img[y:y+h, x:x+w] = cv2.GaussianBlur(img[y:y+h, x:x+w], (99, 99), 30)

    cv2.imwrite(output_path, img)
    return len(faces)

# ──────────────────────────────────────────────
# AUDIT REPORT GENERATION
# ──────────────────────────────────────────────

def generate_audit_report(results: list) -> dict:
    """Generate comprehensive audit report for processed documents."""
    total_pii = sum(len(r.get("entities", [])) for r in results)
    total_tokens = sum(len(r.get("token_map", {})) for r in results)
    avg_risk = (sum(r.get("risk_score", {}).get("score", 0) for r in results) /
                max(len(results), 1))

    label_freq = {}
    for r in results:
        for _, label, *_ in r.get("entities", []):
            label_freq[label] = label_freq.get(label, 0) + 1

    return {
        "generated_at": datetime.now().isoformat(),
        "total_documents": len(results),
        "total_pii_detected": total_pii,
        "total_tokens_created": total_tokens,
        "average_risk_score": round(avg_risk, 1),
        "pii_by_category": label_freq,
        "documents": [{
            "filename": r["filename"],
            "profile": r["profile"],
            "pii_count": len(r.get("entities", [])),
            "risk_score": r.get("risk_score", {}).get("score", 0),
            "risk_level": r.get("risk_score", {}).get("level", "Unknown"),
            "face_count": r.get("face_count", 0),
            "token_count": len(r.get("token_map", {})),
            "error": r.get("error")
        } for r in results]
    }
