"""
ShadowVault Flask Application
All routes: upload, process, vault, entities, dashboard
"""

import os
import json
from pathlib import Path
from flask import (Flask, render_template, request, jsonify,
                   send_file, redirect, url_for, session)
from werkzeug.utils import secure_filename
from shadowvault_core import (
    process_document, retrieve_token, get_all_tokens_for_document,
    get_all_entities, generate_audit_report, COMPLIANCE_PROFILES,
    is_ollama_running, calculate_privacy_risk_score
)
import sqlite3
from shadowvault_core import VAULT_DB

app = Flask(__name__)
app.secret_key = os.urandom(24)

UPLOAD_FOLDER = Path("uploads")
OUTPUT_FOLDER = Path("outputs")
UPLOAD_FOLDER.mkdir(exist_ok=True)
OUTPUT_FOLDER.mkdir(exist_ok=True)

ALLOWED_EXTENSIONS = {"pdf", "jpg", "jpeg", "png", "tiff"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def get_documents_from_db():
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT * FROM documents ORDER BY processed_at DESC")
    rows = c.fetchall()
    conn.close()
    return [{"doc_id": r[0], "filename": r[1], "profile": r[2],
             "risk_score": r[3], "processed_at": r[4], "token_count": r[5]}
            for r in rows]

# ──────────────────────────────────────────────
# ROUTES
# ──────────────────────────────────────────────

@app.route("/")
def index():
    docs = get_documents_from_db()
    entities = get_all_entities()
    ollama_status = is_ollama_running()

    # Dashboard stats
    total_docs = len(docs)
    total_pii = sum(d.get("token_count", 0) for d in docs)
    avg_risk = (sum(d.get("risk_score", 0) or 0 for d in docs) /
                max(total_docs, 1))
    total_entities = len(entities)

    return render_template("index.html",
                           docs=docs,
                           profiles=COMPLIANCE_PROFILES,
                           ollama_status=ollama_status,
                           stats={
                               "total_docs": total_docs,
                               "total_pii": total_pii,
                               "avg_risk": round(avg_risk, 1),
                               "total_entities": total_entities
                           })

@app.route("/process", methods=["POST"])
def process():
    if "files" not in request.files:
        return jsonify({"error": "No files uploaded"}), 400

    files = request.files.getlist("files")
    profile = request.form.get("profile", "GDPR")
    use_llm = request.form.get("use_llm", "true") == "true"
    reversible = request.form.get("reversible", "true") == "true"

    results = []
    for f in files:
        if f and allowed_file(f.filename):
            filename = secure_filename(f.filename)
            save_path = str(UPLOAD_FOLDER / filename)
            f.save(save_path)
            result = process_document(save_path, profile, use_llm, reversible)
            results.append(result)

    if not results:
        return jsonify({"error": "No valid files processed"}), 400

    report = generate_audit_report(results)

    # Serialize entities for JSON
    serialized = []
    for r in results:
        serialized.append({
            "doc_id": r["doc_id"],
            "filename": r["filename"],
            "profile": r["profile"],
            "entity_count": len(r.get("entities", [])),
            "entities": [(v, l, s) for v, l, *s in r.get("entities", [])],
            "token_map": r.get("token_map", {}),
            "risk_score": r.get("risk_score", {}),
            "face_count": r.get("face_count", 0),
            "output_path": r.get("output_path", ""),
            "error": r.get("error")
        })

    return jsonify({"results": serialized, "report": report})

@app.route("/download/<doc_id>")
def download(doc_id):
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT filename FROM documents WHERE doc_id = ?", (doc_id,))
    row = c.fetchone()
    conn.close()
    if not row:
        return "Document not found", 404
    filename = row[0]
    # Find output file
    for f in OUTPUT_FOLDER.iterdir():
        if doc_id[:8] in f.name:
            return send_file(str(f), as_attachment=True,
                             download_name=f"redacted_{filename}")
    return "Output file not found", 404

@app.route("/vault")
def vault():
    role = request.args.get("role", "viewer")
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("""
        SELECT t.token_id, t.pii_label, t.allowed_roles, t.document_id,
               t.created_at, d.filename
        FROM tokens t
        LEFT JOIN documents d ON t.document_id = d.doc_id
        ORDER BY t.created_at DESC
        LIMIT 100
    """)
    rows = c.fetchall()
    conn.close()
    tokens = [{"token_id": r[0], "label": r[1],
               "allowed_roles": json.loads(r[2]),
               "doc_id": r[3], "created_at": r[4],
               "filename": r[5]} for r in rows]
    return render_template("vault.html", tokens=tokens,
                           current_role=role,
                           roles=list({"admin", "doctor", "auditor", "legal", "analyst", "viewer"}))

@app.route("/decrypt", methods=["POST"])
def decrypt():
    data = request.json
    token_id = data.get("token_id")
    role = data.get("role", "viewer")
    if not token_id:
        return jsonify({"error": "Token ID required"}), 400
    result = retrieve_token(token_id, role)
    return jsonify(result)

@app.route("/entities")
def entities():
    all_entities = get_all_entities()
    return render_template("entities.html", entities=all_entities)

@app.route("/api/stats")
def api_stats():
    docs = get_documents_from_db()
    entities = get_all_entities()
    conn = sqlite3.connect(VAULT_DB)
    c = conn.cursor()
    c.execute("SELECT pii_label, COUNT(*) FROM tokens GROUP BY pii_label ORDER BY COUNT(*) DESC")
    label_counts = c.fetchall()
    c.execute("SELECT compliance_profile, COUNT(*) FROM documents GROUP BY compliance_profile")
    profile_counts = c.fetchall()
    conn.close()
    return jsonify({
        "total_docs": len(docs),
        "total_tokens": sum(d.get("token_count", 0) for d in docs),
        "total_entities": len(entities),
        "avg_risk": round(sum(d.get("risk_score", 0) or 0 for d in docs) / max(len(docs), 1), 1),
        "pii_by_label": dict(label_counts),
        "docs_by_profile": dict(profile_counts),
        "ollama_running": is_ollama_running()
    })

if __name__ == "__main__":
    app.run(debug=True, port=5000)
